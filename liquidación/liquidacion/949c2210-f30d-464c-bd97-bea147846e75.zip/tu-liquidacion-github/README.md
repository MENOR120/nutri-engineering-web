# Tu Liquidación al Día — sitio estático

Sitio 100% estático: HTML + CSS + JavaScript + imágenes. No necesita servidor ni build.

## Subir a GitHub Pages

1. Crea un repositorio en GitHub (por ejemplo `tu-liquidacion`).
2. Sube **todo el contenido de esta carpeta** a la raíz del repositorio
   (los archivos, no la carpeta que los contiene). Incluye el archivo oculto `.nojekyll`.
3. En el repo: **Settings → Pages → Build and deployment**
   - Source: `Deploy from a branch`
   - Branch: `main` / carpeta `/ (root)` → **Save**
4. En 1–2 minutos el sitio queda en `https://TU-USUARIO.github.io/tu-liquidacion/`.

Las rutas son relativas, así que funciona igual en la raíz de un dominio propio
o en una subcarpeta tipo `/tu-liquidacion/`.

## Contenido

- `index.html` — página
- `assets/index-*.css` — estilos
- `assets/index-*.js` — JavaScript
- `images/` — 6 imágenes del producto
- `favicon.ico`, `og-image.png` — icono y vista previa para redes
- `.nojekyll` — obligatorio: evita que GitHub Pages ignore la carpeta `assets`

## Editar el enlace de WhatsApp

El enlace `https://wa.me/message/QV7VXYUHNKANB1` está en `assets/index-*.js`.
Para cambiarlo, busca y reemplaza ese texto en ese archivo (aparece una sola vez).

## Probar en local

```bash
python3 -m http.server 8000
```
Y abre `http://localhost:8000`.
